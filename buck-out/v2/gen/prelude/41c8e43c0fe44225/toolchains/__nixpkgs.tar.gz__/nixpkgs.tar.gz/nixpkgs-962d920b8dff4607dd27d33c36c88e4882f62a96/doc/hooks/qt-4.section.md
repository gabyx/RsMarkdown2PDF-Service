
### Qt 4 {#qt-4}

Sets the `QTDIR` environment variable to Qt’s path.
