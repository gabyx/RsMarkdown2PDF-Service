#!/bin/sh

printf "%s" "${name:?}" > "${out:?}"
