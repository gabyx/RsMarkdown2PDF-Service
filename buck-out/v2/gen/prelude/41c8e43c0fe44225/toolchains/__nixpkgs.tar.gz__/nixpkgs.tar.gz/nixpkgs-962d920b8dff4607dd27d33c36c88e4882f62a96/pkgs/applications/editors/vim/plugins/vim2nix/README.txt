Usage see vim-utils.nix in nixpkgs

This code depends on vim-addon-manager
