Instructions for adding Vim plugins to `nixpkgs` can be found [here](/doc/languages-frameworks/vim.section.md).
