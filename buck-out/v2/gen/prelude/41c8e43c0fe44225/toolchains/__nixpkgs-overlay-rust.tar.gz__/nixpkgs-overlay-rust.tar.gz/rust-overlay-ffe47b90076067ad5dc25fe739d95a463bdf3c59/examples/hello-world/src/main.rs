fn main() {
    // Trigger a clippy warning.
    loop {
        break;
    }
    println!("Hello, world!");
}
